﻿namespace Viitorul_este_acum
{
    partial class FormProgramZi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSus = new System.Windows.Forms.Panel();
            this.buttonReincarca = new System.Windows.Forms.Button();
            this.labelZiua = new System.Windows.Forms.Label();
            this.panelJos = new System.Windows.Forms.Panel();
            this.panelSus.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSus
            // 
            this.panelSus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelSus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.panelSus.Controls.Add(this.buttonReincarca);
            this.panelSus.Controls.Add(this.labelZiua);
            this.panelSus.Location = new System.Drawing.Point(0, 0);
            this.panelSus.Name = "panelSus";
            this.panelSus.Size = new System.Drawing.Size(480, 53);
            this.panelSus.TabIndex = 7;
            // 
            // buttonReincarca
            // 
            this.buttonReincarca.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonReincarca.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReincarca.Location = new System.Drawing.Point(4, 4);
            this.buttonReincarca.Name = "buttonReincarca";
            this.buttonReincarca.Size = new System.Drawing.Size(102, 23);
            this.buttonReincarca.TabIndex = 8;
            this.buttonReincarca.Text = "Reincarca pagina";
            this.buttonReincarca.UseVisualStyleBackColor = true;
            this.buttonReincarca.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelZiua
            // 
            this.labelZiua.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelZiua.AutoSize = true;
            this.labelZiua.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelZiua.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.labelZiua.Location = new System.Drawing.Point(69, 9);
            this.labelZiua.Name = "labelZiua";
            this.labelZiua.Size = new System.Drawing.Size(100, 33);
            this.labelZiua.TabIndex = 7;
            this.labelZiua.Text = "labelZiua";
            // 
            // panelJos
            // 
            this.panelJos.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelJos.AutoScroll = true;
            this.panelJos.Location = new System.Drawing.Point(0, 53);
            this.panelJos.Name = "panelJos";
            this.panelJos.Size = new System.Drawing.Size(480, 397);
            this.panelJos.TabIndex = 8;
            this.panelJos.Paint += new System.Windows.Forms.PaintEventHandler(this.panelJos_Paint);
            // 
            // FormProgramZi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.ClientSize = new System.Drawing.Size(480, 450);
            this.Controls.Add(this.panelJos);
            this.Controls.Add(this.panelSus);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "FormProgramZi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormProgramZi";
            this.Load += new System.EventHandler(this.FormProgramZi_Load);
            this.panelSus.ResumeLayout(false);
            this.panelSus.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelSus;
        private System.Windows.Forms.Label labelZiua;
        private System.Windows.Forms.Panel panelJos;
        private System.Windows.Forms.Button buttonReincarca;
    }
}