﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Viitorul_este_acum
{
    public partial class FormStart : Form
    {
        bool esteAutentificare = true;
        

        public FormStart()
        {
            InitializeComponent();
            button1.FlatAppearance.BorderSize = 1;
        }

        private void FormStart_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.FromArgb(102, 252, 241);
            esteAutentificare = true;
            button1.FlatAppearance.BorderSize = 1;
            button2.FlatAppearance.BorderSize = 0;
            textBoxNumeAutentificare.BackColor = Color.FromArgb(102, 252, 241);
            textBoxParolaAutentificare.BackColor = Color.FromArgb(102, 252, 241);
            buttonAutentificare.Text = "Intră în cont";
            radioButtonElev.Visible = false;
            radioButtonProf.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            this.BackColor = Color.FromArgb(69, 162, 158);
            esteAutentificare = false;
            button2.FlatAppearance.BorderSize = 1;
            button1.FlatAppearance.BorderSize = 0;
            textBoxNumeAutentificare.BackColor = Color.FromArgb(69, 162, 158);
            textBoxParolaAutentificare.BackColor = Color.FromArgb(69, 162, 158);
            buttonAutentificare.Text = "Crează un cont nou";
            radioButtonElev.Visible = true;
            radioButtonProf.Visible = true;
        }

        private bool areLiteraMare(string x)
        {
            for (int i = 0; i < x.Length; i++)
                if (char.IsUpper(x[i]))
                    return true;
            return false;
        }

        private bool areCifra (string x)
        {
            for (int i = 0; i < x.Length; i++)
                if (char.IsDigit(x[i]))
                    return true;
            return false;
        }

        private bool areCaracterSpecial(string x)
        {
            for (int i = 0; i < x.Length; i++)
                if (!(char.IsLetterOrDigit(x[i])))
                    return true;
            return false;
        }

        private void IncarcaCulori(int x)
        {
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand selectie = new SqlCommand("SELECT * FROM TabelCulori WHERE IdColorScheme = '" + x + "'", conexiune);
            SqlDataReader dr = selectie.ExecuteReader();
            if(dr.Read())
            {
                for (int i = 0; i < 7; i++)
                    VariabileGlobale.culori[i] = ColorTranslator.FromHtml(Convert.ToString(dr[i + 3]));
            }
            dr.Close();
            conexiune.Close();
        }

        private void buttonAutentificare_Click(object sender, EventArgs e)
        {
            if(esteAutentificare == true)
            {
                if(textBoxNumeAutentificare.Text == "" || textBoxParolaAutentificare.Text == "")
                {
                    MessageBox.Show("Introduceți toate datele!");
                    return;
                }
                string parola = textBoxParolaAutentificare.Text, nume = textBoxNumeAutentificare.Text;
                SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
                conexiune.Open();
                SqlCommand selectie = new SqlCommand("SELECT ColorScheme , IdUtilizator , EsteElev FROM TabelUtilizatori WHERE Parola = '" + parola + "' AND NumeUtilizator = '" + nume + "'", conexiune);
                SqlDataReader dr = selectie.ExecuteReader();
                if (dr.Read())
                {
                    VariabileGlobale.colorScheme = Convert.ToInt32(dr[0]);
                    VariabileGlobale.idCurent = Convert.ToInt32(dr[1]);
                    VariabileGlobale.numeCurent = nume;
                    IncarcaCulori(Convert.ToInt32(dr[0]));
                    VariabileGlobale.EsteElev = Convert.ToInt32(dr[2]);
                    FormPrincipal fp = new FormPrincipal();
                    dr.Close();
                    conexiune.Close();
                    this.Hide();
                    fp.ShowDialog();
                }
                else
                    MessageBox.Show("Numele sau parola gresite");
                if (!dr.IsClosed)
                    dr.Close();
                conexiune.Close();
            }
            else
            {
                if (textBoxNumeAutentificare.Text == "" || textBoxParolaAutentificare.Text == "")
                {
                    MessageBox.Show("Introduceți toate datele!");
                    return;
                }
                string parola = textBoxParolaAutentificare.Text, nume = textBoxNumeAutentificare.Text;
                if (!(areCifra(parola) && areLiteraMare(parola) && parola.Length >= 8 && areCaracterSpecial(parola)))
                {
                    MessageBox.Show("Parola nu respecta regulile: cel putin: 8 caractere, o litera mare, o cifra, un caracter special");
                    return;
                }
                if (radioButtonElev.Checked == true)
                    VariabileGlobale.EsteElev = 1;
                else
                    VariabileGlobale.EsteElev = 0;
                SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
                conexiune.Open();
                SqlCommand selectie = new SqlCommand("SELECT IdUtilizator FROM TabelUtilizatori WHERE NumeUtilizator = '" + nume + "'", conexiune);
                SqlDataReader dr = selectie.ExecuteReader();
                if (dr.Read())
                {
                    
                    MessageBox.Show("Numele de utilizator " + nume + " există deja");
                    return;
                }
                dr.Close();
                SqlCommand insertie = new SqlCommand("INSERT INTO TabelUtilizatori (NumeUtilizator , Parola , EsteElev) VALUES ('" + nume + "' , '" + parola + "' , '" + VariabileGlobale.EsteElev + "')", conexiune);
                insertie.ExecuteNonQuery();
                MessageBox.Show("Contul cu numele de utilizator " + nume + " a fost adăugat");
                conexiune.Close();
                button1.PerformClick();
            }
        }

        private void buttonHide_Click(object sender, EventArgs e)
        {
            if (textBoxParolaAutentificare.PasswordChar == 0)
            {
                textBoxParolaAutentificare.PasswordChar = '*';
                return;
            }
            if (textBoxParolaAutentificare.PasswordChar == '*')
                textBoxParolaAutentificare.PasswordChar = '\0';


        }

        private void buttonX_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonMinimise_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                FormStart fs = new FormStart();
                this.Hide();
                fs.ShowDialog();
            }
            else
            {
                MessageBox.Show("" + panel1.Width);
                this.WindowState = FormWindowState.Maximized;
                MessageBox.Show("" + panel1.Width);
                label1.MaximumSize = new Size(this.Width - 100, 5000);
                button1.Size = new Size(button1.Height, panel1.Width / 2 - 5);
                button2.Size = new Size(button2.Height, panel1.Width / 2 - 5);
                button1.Location = new Point(0, 0);
                button1.Location = new Point(0, panel1.Width / 2 + 5);
            }
        }

    }
    public static class VariabileGlobale
    {
        public static string connString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""|DataDirectory|BazaDeDateViitorulEsteAcum.mdf"";Integrated Security=True;Connect Timeout=30";
        public static int idCurent;
        public static string numeCurent;
        public static int colorScheme = 1;
        public static DateTime dataCurenta;
        public static Color[] culori = new Color[8];
        public static int EsteElev = 0;
        public static string[] categorii = new string[22];
        public static string[] indrumatori = new string[22];
        public static int m = 0;
    }
}
