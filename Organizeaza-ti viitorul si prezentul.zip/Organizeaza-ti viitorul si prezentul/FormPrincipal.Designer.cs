﻿namespace Viitorul_este_acum
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelStanga = new System.Windows.Forms.Panel();
            this.buttonMeniu = new System.Windows.Forms.Button();
            this.buttonCalendar = new System.Windows.Forms.Button();
            this.buttonCulori = new System.Windows.Forms.Button();
            this.buttonAdauga = new System.Windows.Forms.Button();
            this.panelSus = new System.Windows.Forms.Panel();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonMinimise = new System.Windows.Forms.Button();
            this.labelNumeUtilizator = new System.Windows.Forms.Label();
            this.panelCalendar = new System.Windows.Forms.Panel();
            this.buttonArataCalendarul = new System.Windows.Forms.Button();
            this.buttonMareLuna = new System.Windows.Forms.Button();
            this.buttonMareAn = new System.Windows.Forms.Button();
            this.buttonMicAn = new System.Windows.Forms.Button();
            this.buttonMicLuna = new System.Windows.Forms.Button();
            this.labelAn = new System.Windows.Forms.Label();
            this.labelLuna = new System.Windows.Forms.Label();
            this.panelPaleteCulori = new System.Windows.Forms.Panel();
            this.buttonAplica = new System.Windows.Forms.Button();
            this.labelSelecteazaPaleta = new System.Windows.Forms.Label();
            this.comboBoxPaleta = new System.Windows.Forms.ComboBox();
            this.buttonSelecteazaPaleta = new System.Windows.Forms.Button();
            this.buttonAdaugaPaleta = new System.Windows.Forms.Button();
            this.panelAdaugare = new System.Windows.Forms.Panel();
            this.comboBoxCategorie = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonAdaugare = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxDetalii = new System.Windows.Forms.TextBox();
            this.textBoxTitlu = new System.Windows.Forms.TextBox();
            this.radioButtonNuSeRepeta = new System.Windows.Forms.RadioButton();
            this.radioButtonSeRepeta = new System.Windows.Forms.RadioButton();
            this.checkedListBoxZile = new System.Windows.Forms.CheckedListBox();
            this.panelCulori = new System.Windows.Forms.Panel();
            this.textBoxTitluSchema = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.buttonIntrodu = new System.Windows.Forms.Button();
            this.panelEx = new System.Windows.Forms.Panel();
            this.buttonEx2 = new System.Windows.Forms.Button();
            this.buttonex3 = new System.Windows.Forms.Button();
            this.buttonEx1 = new System.Windows.Forms.Button();
            this.panelEx1 = new System.Windows.Forms.Panel();
            this.labelExSus = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxCulori = new System.Windows.Forms.ComboBox();
            this.buttonSelectareCulori = new System.Windows.Forms.Button();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.panelUrmarire = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonUrmareste = new System.Windows.Forms.Button();
            this.comboBoxNume = new System.Windows.Forms.ComboBox();
            this.comboBoxCategoria = new System.Windows.Forms.ComboBox();
            this.panelStanga.SuspendLayout();
            this.panelSus.SuspendLayout();
            this.panelCalendar.SuspendLayout();
            this.panelPaleteCulori.SuspendLayout();
            this.panelAdaugare.SuspendLayout();
            this.panelCulori.SuspendLayout();
            this.panelEx.SuspendLayout();
            this.panelEx1.SuspendLayout();
            this.panelUrmarire.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelStanga
            // 
            this.panelStanga.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.panelStanga.Controls.Add(this.buttonMeniu);
            this.panelStanga.Controls.Add(this.buttonCalendar);
            this.panelStanga.Controls.Add(this.buttonCulori);
            this.panelStanga.Controls.Add(this.buttonAdauga);
            this.panelStanga.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelStanga.Location = new System.Drawing.Point(0, 0);
            this.panelStanga.Name = "panelStanga";
            this.panelStanga.Size = new System.Drawing.Size(172, 412);
            this.panelStanga.TabIndex = 0;
            this.panelStanga.Paint += new System.Windows.Forms.PaintEventHandler(this.panelStanga_Paint);
            // 
            // buttonMeniu
            // 
            this.buttonMeniu.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonMeniu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMeniu.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMeniu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonMeniu.Location = new System.Drawing.Point(0, 3);
            this.buttonMeniu.Name = "buttonMeniu";
            this.buttonMeniu.Size = new System.Drawing.Size(169, 77);
            this.buttonMeniu.TabIndex = 6;
            this.buttonMeniu.Text = "Înapoi la meniu";
            this.buttonMeniu.UseVisualStyleBackColor = true;
            this.buttonMeniu.Click += new System.EventHandler(this.buttonMeniu_Click);
            // 
            // buttonCalendar
            // 
            this.buttonCalendar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonCalendar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCalendar.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalendar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonCalendar.Location = new System.Drawing.Point(0, 86);
            this.buttonCalendar.Name = "buttonCalendar";
            this.buttonCalendar.Size = new System.Drawing.Size(169, 59);
            this.buttonCalendar.TabIndex = 5;
            this.buttonCalendar.Text = "Calendar";
            this.buttonCalendar.UseVisualStyleBackColor = true;
            this.buttonCalendar.Click += new System.EventHandler(this.buttonCalendar_Click);
            // 
            // buttonCulori
            // 
            this.buttonCulori.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonCulori.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCulori.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCulori.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonCulori.Location = new System.Drawing.Point(0, 216);
            this.buttonCulori.Name = "buttonCulori";
            this.buttonCulori.Size = new System.Drawing.Size(169, 59);
            this.buttonCulori.TabIndex = 3;
            this.buttonCulori.Text = "Schimbă culorile";
            this.buttonCulori.UseVisualStyleBackColor = true;
            this.buttonCulori.Click += new System.EventHandler(this.buttonCulori_Click);
            // 
            // buttonAdauga
            // 
            this.buttonAdauga.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonAdauga.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAdauga.Font = new System.Drawing.Font("Segoe Print", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdauga.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonAdauga.Location = new System.Drawing.Point(0, 151);
            this.buttonAdauga.Name = "buttonAdauga";
            this.buttonAdauga.Size = new System.Drawing.Size(169, 59);
            this.buttonAdauga.TabIndex = 2;
            this.buttonAdauga.Text = "Adaugă un eveniment";
            this.buttonAdauga.UseVisualStyleBackColor = true;
            this.buttonAdauga.Click += new System.EventHandler(this.buttonAdauga_Click);
            // 
            // panelSus
            // 
            this.panelSus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.panelSus.Controls.Add(this.buttonX);
            this.panelSus.Controls.Add(this.buttonMinimise);
            this.panelSus.Controls.Add(this.labelNumeUtilizator);
            this.panelSus.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSus.Location = new System.Drawing.Point(172, 0);
            this.panelSus.Name = "panelSus";
            this.panelSus.Size = new System.Drawing.Size(512, 57);
            this.panelSus.TabIndex = 1;
            this.panelSus.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSus_Paint);
            // 
            // buttonX
            // 
            this.buttonX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonX.ForeColor = System.Drawing.Color.Black;
            this.buttonX.Location = new System.Drawing.Point(480, 3);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(20, 22);
            this.buttonX.TabIndex = 3;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = true;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            // 
            // buttonMinimise
            // 
            this.buttonMinimise.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMinimise.ForeColor = System.Drawing.Color.Black;
            this.buttonMinimise.Location = new System.Drawing.Point(454, 3);
            this.buttonMinimise.Name = "buttonMinimise";
            this.buttonMinimise.Size = new System.Drawing.Size(20, 22);
            this.buttonMinimise.TabIndex = 2;
            this.buttonMinimise.Text = "-";
            this.buttonMinimise.UseVisualStyleBackColor = true;
            this.buttonMinimise.Click += new System.EventHandler(this.buttonMinimise_Click);
            // 
            // labelNumeUtilizator
            // 
            this.labelNumeUtilizator.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelNumeUtilizator.AutoSize = true;
            this.labelNumeUtilizator.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumeUtilizator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.labelNumeUtilizator.Location = new System.Drawing.Point(237, 9);
            this.labelNumeUtilizator.Name = "labelNumeUtilizator";
            this.labelNumeUtilizator.Size = new System.Drawing.Size(79, 37);
            this.labelNumeUtilizator.TabIndex = 0;
            this.labelNumeUtilizator.Text = "label1";
            this.labelNumeUtilizator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelNumeUtilizator.Click += new System.EventHandler(this.labelNumeUtilizator_Click);
            // 
            // panelCalendar
            // 
            this.panelCalendar.Controls.Add(this.buttonArataCalendarul);
            this.panelCalendar.Controls.Add(this.buttonMareLuna);
            this.panelCalendar.Controls.Add(this.buttonMareAn);
            this.panelCalendar.Controls.Add(this.buttonMicAn);
            this.panelCalendar.Controls.Add(this.buttonMicLuna);
            this.panelCalendar.Controls.Add(this.labelAn);
            this.panelCalendar.Controls.Add(this.labelLuna);
            this.panelCalendar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCalendar.Location = new System.Drawing.Point(172, 57);
            this.panelCalendar.Name = "panelCalendar";
            this.panelCalendar.Size = new System.Drawing.Size(512, 355);
            this.panelCalendar.TabIndex = 2;
            this.panelCalendar.Visible = false;
            this.panelCalendar.Paint += new System.Windows.Forms.PaintEventHandler(this.panelCalendar_Paint);
            // 
            // buttonArataCalendarul
            // 
            this.buttonArataCalendarul.Location = new System.Drawing.Point(372, 42);
            this.buttonArataCalendarul.Name = "buttonArataCalendarul";
            this.buttonArataCalendarul.Size = new System.Drawing.Size(107, 23);
            this.buttonArataCalendarul.TabIndex = 15;
            this.buttonArataCalendarul.Text = "Incarca Calendarul";
            this.buttonArataCalendarul.UseVisualStyleBackColor = true;
            this.buttonArataCalendarul.Click += new System.EventHandler(this.buttonArataCalendarul_Click);
            // 
            // buttonMareLuna
            // 
            this.buttonMareLuna.Location = new System.Drawing.Point(316, 18);
            this.buttonMareLuna.Name = "buttonMareLuna";
            this.buttonMareLuna.Size = new System.Drawing.Size(21, 23);
            this.buttonMareLuna.TabIndex = 14;
            this.buttonMareLuna.Text = ">";
            this.buttonMareLuna.UseVisualStyleBackColor = true;
            this.buttonMareLuna.Click += new System.EventHandler(this.buttonMareLuna_Click);
            // 
            // buttonMareAn
            // 
            this.buttonMareAn.Location = new System.Drawing.Point(316, 58);
            this.buttonMareAn.Name = "buttonMareAn";
            this.buttonMareAn.Size = new System.Drawing.Size(21, 23);
            this.buttonMareAn.TabIndex = 13;
            this.buttonMareAn.Text = ">";
            this.buttonMareAn.UseVisualStyleBackColor = true;
            this.buttonMareAn.Click += new System.EventHandler(this.buttonMareAn_Click);
            // 
            // buttonMicAn
            // 
            this.buttonMicAn.Location = new System.Drawing.Point(172, 59);
            this.buttonMicAn.Name = "buttonMicAn";
            this.buttonMicAn.Size = new System.Drawing.Size(21, 23);
            this.buttonMicAn.TabIndex = 12;
            this.buttonMicAn.Text = "<";
            this.buttonMicAn.UseVisualStyleBackColor = true;
            this.buttonMicAn.Click += new System.EventHandler(this.buttonMicAn_Click);
            // 
            // buttonMicLuna
            // 
            this.buttonMicLuna.Location = new System.Drawing.Point(172, 13);
            this.buttonMicLuna.Name = "buttonMicLuna";
            this.buttonMicLuna.Size = new System.Drawing.Size(21, 23);
            this.buttonMicLuna.TabIndex = 11;
            this.buttonMicLuna.Text = "<";
            this.buttonMicLuna.UseVisualStyleBackColor = true;
            this.buttonMicLuna.Click += new System.EventHandler(this.buttonMicLuna_Click);
            // 
            // labelAn
            // 
            this.labelAn.AutoSize = true;
            this.labelAn.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.labelAn.Location = new System.Drawing.Point(209, 47);
            this.labelAn.Name = "labelAn";
            this.labelAn.Size = new System.Drawing.Size(87, 43);
            this.labelAn.TabIndex = 10;
            this.labelAn.Text = "2022";
            this.labelAn.Click += new System.EventHandler(this.labelAn_Click);
            // 
            // labelLuna
            // 
            this.labelLuna.AutoSize = true;
            this.labelLuna.Font = new System.Drawing.Font("Segoe Print", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLuna.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.labelLuna.Location = new System.Drawing.Point(199, 0);
            this.labelLuna.Name = "labelLuna";
            this.labelLuna.Size = new System.Drawing.Size(111, 47);
            this.labelLuna.TabIndex = 9;
            this.labelLuna.Text = "Martie";
            this.labelLuna.Click += new System.EventHandler(this.labelLuna_Click);
            // 
            // panelPaleteCulori
            // 
            this.panelPaleteCulori.Controls.Add(this.buttonAplica);
            this.panelPaleteCulori.Controls.Add(this.labelSelecteazaPaleta);
            this.panelPaleteCulori.Controls.Add(this.comboBoxPaleta);
            this.panelPaleteCulori.Controls.Add(this.buttonSelecteazaPaleta);
            this.panelPaleteCulori.Controls.Add(this.buttonAdaugaPaleta);
            this.panelPaleteCulori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPaleteCulori.Location = new System.Drawing.Point(172, 57);
            this.panelPaleteCulori.Name = "panelPaleteCulori";
            this.panelPaleteCulori.Size = new System.Drawing.Size(512, 355);
            this.panelPaleteCulori.TabIndex = 3;
            this.panelPaleteCulori.Visible = false;
            this.panelPaleteCulori.Paint += new System.Windows.Forms.PaintEventHandler(this.panelPaleteCulori_Paint);
            // 
            // buttonAplica
            // 
            this.buttonAplica.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.buttonAplica.FlatAppearance.BorderSize = 3;
            this.buttonAplica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAplica.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAplica.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonAplica.Location = new System.Drawing.Point(353, 260);
            this.buttonAplica.Name = "buttonAplica";
            this.buttonAplica.Size = new System.Drawing.Size(136, 54);
            this.buttonAplica.TabIndex = 4;
            this.buttonAplica.Text = "Aplica";
            this.buttonAplica.UseVisualStyleBackColor = false;
            this.buttonAplica.Visible = false;
            this.buttonAplica.Click += new System.EventHandler(this.buttonAplica_Click);
            // 
            // labelSelecteazaPaleta
            // 
            this.labelSelecteazaPaleta.AutoSize = true;
            this.labelSelecteazaPaleta.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSelecteazaPaleta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.labelSelecteazaPaleta.Location = new System.Drawing.Point(6, 275);
            this.labelSelecteazaPaleta.Name = "labelSelecteazaPaleta";
            this.labelSelecteazaPaleta.Size = new System.Drawing.Size(143, 28);
            this.labelSelecteazaPaleta.TabIndex = 3;
            this.labelSelecteazaPaleta.Text = "selecteaza paleta";
            this.labelSelecteazaPaleta.Visible = false;
            // 
            // comboBoxPaleta
            // 
            this.comboBoxPaleta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxPaleta.FormattingEnabled = true;
            this.comboBoxPaleta.Location = new System.Drawing.Point(156, 275);
            this.comboBoxPaleta.Name = "comboBoxPaleta";
            this.comboBoxPaleta.Size = new System.Drawing.Size(160, 21);
            this.comboBoxPaleta.TabIndex = 2;
            this.comboBoxPaleta.Visible = false;
            // 
            // buttonSelecteazaPaleta
            // 
            this.buttonSelecteazaPaleta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.buttonSelecteazaPaleta.FlatAppearance.BorderSize = 3;
            this.buttonSelecteazaPaleta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSelecteazaPaleta.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSelecteazaPaleta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonSelecteazaPaleta.Location = new System.Drawing.Point(156, 135);
            this.buttonSelecteazaPaleta.Name = "buttonSelecteazaPaleta";
            this.buttonSelecteazaPaleta.Size = new System.Drawing.Size(206, 83);
            this.buttonSelecteazaPaleta.TabIndex = 1;
            this.buttonSelecteazaPaleta.Text = "Selecteaza o paleta de culori";
            this.buttonSelecteazaPaleta.UseVisualStyleBackColor = false;
            this.buttonSelecteazaPaleta.Click += new System.EventHandler(this.buttonSelecteazaPaleta_Click);
            // 
            // buttonAdaugaPaleta
            // 
            this.buttonAdaugaPaleta.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.buttonAdaugaPaleta.FlatAppearance.BorderSize = 3;
            this.buttonAdaugaPaleta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAdaugaPaleta.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdaugaPaleta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonAdaugaPaleta.Location = new System.Drawing.Point(156, 29);
            this.buttonAdaugaPaleta.Name = "buttonAdaugaPaleta";
            this.buttonAdaugaPaleta.Size = new System.Drawing.Size(206, 85);
            this.buttonAdaugaPaleta.TabIndex = 0;
            this.buttonAdaugaPaleta.Text = "Adauga o paleta noua de culori";
            this.buttonAdaugaPaleta.UseVisualStyleBackColor = false;
            this.buttonAdaugaPaleta.Click += new System.EventHandler(this.buttonAdaugaPaleta_Click);
            // 
            // panelAdaugare
            // 
            this.panelAdaugare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.panelAdaugare.Controls.Add(this.comboBoxCategorie);
            this.panelAdaugare.Controls.Add(this.label3);
            this.panelAdaugare.Controls.Add(this.panel2);
            this.panelAdaugare.Controls.Add(this.panel1);
            this.panelAdaugare.Controls.Add(this.buttonAdaugare);
            this.panelAdaugare.Controls.Add(this.label2);
            this.panelAdaugare.Controls.Add(this.label1);
            this.panelAdaugare.Controls.Add(this.textBoxDetalii);
            this.panelAdaugare.Controls.Add(this.textBoxTitlu);
            this.panelAdaugare.Controls.Add(this.radioButtonNuSeRepeta);
            this.panelAdaugare.Controls.Add(this.radioButtonSeRepeta);
            this.panelAdaugare.Controls.Add(this.checkedListBoxZile);
            this.panelAdaugare.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAdaugare.Location = new System.Drawing.Point(172, 57);
            this.panelAdaugare.Name = "panelAdaugare";
            this.panelAdaugare.Size = new System.Drawing.Size(512, 355);
            this.panelAdaugare.TabIndex = 16;
            this.panelAdaugare.Visible = false;
            this.panelAdaugare.Paint += new System.Windows.Forms.PaintEventHandler(this.panelAdaugare_Paint);
            // 
            // comboBoxCategorie
            // 
            this.comboBoxCategorie.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCategorie.FormattingEnabled = true;
            this.comboBoxCategorie.Items.AddRange(new object[] {
            "Informatica",
            "Muzica",
            "Stiinte",
            "Sport",
            "Lingvistica/Lectura",
            "Altele"});
            this.comboBoxCategorie.Location = new System.Drawing.Point(317, 171);
            this.comboBoxCategorie.Name = "comboBoxCategorie";
            this.comboBoxCategorie.Size = new System.Drawing.Size(172, 21);
            this.comboBoxCategorie.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.label3.Location = new System.Drawing.Point(202, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 28);
            this.label3.TabIndex = 18;
            this.label3.Text = "Categorie";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(317, 103);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(164, 1);
            this.panel2.TabIndex = 14;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(316, 46);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(164, 1);
            this.panel1.TabIndex = 13;
            // 
            // buttonAdaugare
            // 
            this.buttonAdaugare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.buttonAdaugare.FlatAppearance.BorderSize = 3;
            this.buttonAdaugare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAdaugare.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAdaugare.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonAdaugare.Location = new System.Drawing.Point(145, 302);
            this.buttonAdaugare.Name = "buttonAdaugare";
            this.buttonAdaugare.Size = new System.Drawing.Size(227, 48);
            this.buttonAdaugare.TabIndex = 12;
            this.buttonAdaugare.Text = "Adauga in program";
            this.buttonAdaugare.UseVisualStyleBackColor = false;
            this.buttonAdaugare.Click += new System.EventHandler(this.buttonAdaugare_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.label2.Location = new System.Drawing.Point(157, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 28);
            this.label2.TabIndex = 6;
            this.label2.Text = "Detalii eveniment";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.label1.Location = new System.Drawing.Point(167, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 28);
            this.label1.TabIndex = 5;
            this.label1.Text = "Titlu eveniment";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBoxDetalii
            // 
            this.textBoxDetalii.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.textBoxDetalii.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDetalii.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDetalii.Location = new System.Drawing.Point(317, 58);
            this.textBoxDetalii.Multiline = true;
            this.textBoxDetalii.Name = "textBoxDetalii";
            this.textBoxDetalii.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDetalii.Size = new System.Drawing.Size(163, 39);
            this.textBoxDetalii.TabIndex = 4;
            this.textBoxDetalii.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBoxTitlu
            // 
            this.textBoxTitlu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.textBoxTitlu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTitlu.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTitlu.Location = new System.Drawing.Point(316, 19);
            this.textBoxTitlu.Name = "textBoxTitlu";
            this.textBoxTitlu.Size = new System.Drawing.Size(163, 29);
            this.textBoxTitlu.TabIndex = 3;
            this.textBoxTitlu.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // radioButtonNuSeRepeta
            // 
            this.radioButtonNuSeRepeta.AutoSize = true;
            this.radioButtonNuSeRepeta.Checked = true;
            this.radioButtonNuSeRepeta.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonNuSeRepeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.radioButtonNuSeRepeta.Location = new System.Drawing.Point(6, 259);
            this.radioButtonNuSeRepeta.Name = "radioButtonNuSeRepeta";
            this.radioButtonNuSeRepeta.Size = new System.Drawing.Size(366, 37);
            this.radioButtonNuSeRepeta.TabIndex = 2;
            this.radioButtonNuSeRepeta.TabStop = true;
            this.radioButtonNuSeRepeta.Text = "Nu se repeta in fiecare saptamana";
            this.radioButtonNuSeRepeta.UseVisualStyleBackColor = true;
            this.radioButtonNuSeRepeta.CheckedChanged += new System.EventHandler(this.radioButtonNuSeRepeta_CheckedChanged);
            // 
            // radioButtonSeRepeta
            // 
            this.radioButtonSeRepeta.AutoSize = true;
            this.radioButtonSeRepeta.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonSeRepeta.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.radioButtonSeRepeta.Location = new System.Drawing.Point(6, 224);
            this.radioButtonSeRepeta.Name = "radioButtonSeRepeta";
            this.radioButtonSeRepeta.Size = new System.Drawing.Size(335, 37);
            this.radioButtonSeRepeta.TabIndex = 1;
            this.radioButtonSeRepeta.Text = "Se repeta in fiecare saptamana";
            this.radioButtonSeRepeta.UseVisualStyleBackColor = true;
            this.radioButtonSeRepeta.CheckedChanged += new System.EventHandler(this.radioButtonSeRepeta_CheckedChanged);
            // 
            // checkedListBoxZile
            // 
            this.checkedListBoxZile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.checkedListBoxZile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.checkedListBoxZile.CheckOnClick = true;
            this.checkedListBoxZile.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkedListBoxZile.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.checkedListBoxZile.FormattingEnabled = true;
            this.checkedListBoxZile.Items.AddRange(new object[] {
            "Luni ",
            "Marti ",
            "Miercuri",
            "Joi ",
            "Vineri",
            "Sambata",
            "Duminica"});
            this.checkedListBoxZile.Location = new System.Drawing.Point(13, 3);
            this.checkedListBoxZile.Name = "checkedListBoxZile";
            this.checkedListBoxZile.Size = new System.Drawing.Size(120, 217);
            this.checkedListBoxZile.TabIndex = 0;
            this.checkedListBoxZile.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxZile_SelectedIndexChanged);
            // 
            // panelCulori
            // 
            this.panelCulori.Controls.Add(this.textBoxTitluSchema);
            this.panelCulori.Controls.Add(this.label7);
            this.panelCulori.Controls.Add(this.buttonIntrodu);
            this.panelCulori.Controls.Add(this.panelEx);
            this.panelCulori.Controls.Add(this.label6);
            this.panelCulori.Controls.Add(this.comboBoxCulori);
            this.panelCulori.Controls.Add(this.buttonSelectareCulori);
            this.panelCulori.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCulori.Location = new System.Drawing.Point(172, 57);
            this.panelCulori.Name = "panelCulori";
            this.panelCulori.Size = new System.Drawing.Size(512, 355);
            this.panelCulori.TabIndex = 17;
            this.panelCulori.Visible = false;
            this.panelCulori.Paint += new System.Windows.Forms.PaintEventHandler(this.panelCulori_Paint);
            // 
            // textBoxTitluSchema
            // 
            this.textBoxTitluSchema.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTitluSchema.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.textBoxTitluSchema.Location = new System.Drawing.Point(13, 197);
            this.textBoxTitluSchema.Name = "textBoxTitluSchema";
            this.textBoxTitluSchema.Size = new System.Drawing.Size(224, 36);
            this.textBoxTitluSchema.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.label7.Location = new System.Drawing.Point(8, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(230, 28);
            this.label7.TabIndex = 5;
            this.label7.Text = "Titlul noii scheme de culori";
            // 
            // buttonIntrodu
            // 
            this.buttonIntrodu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.buttonIntrodu.FlatAppearance.BorderSize = 2;
            this.buttonIntrodu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonIntrodu.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonIntrodu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonIntrodu.Location = new System.Drawing.Point(8, 302);
            this.buttonIntrodu.Name = "buttonIntrodu";
            this.buttonIntrodu.Size = new System.Drawing.Size(229, 44);
            this.buttonIntrodu.TabIndex = 4;
            this.buttonIntrodu.Text = "Introdu schema de culori";
            this.buttonIntrodu.UseVisualStyleBackColor = false;
            this.buttonIntrodu.Click += new System.EventHandler(this.buttonIntrodu_Click);
            // 
            // panelEx
            // 
            this.panelEx.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelEx.Controls.Add(this.buttonEx2);
            this.panelEx.Controls.Add(this.buttonex3);
            this.panelEx.Controls.Add(this.buttonEx1);
            this.panelEx.Controls.Add(this.panelEx1);
            this.panelEx.Location = new System.Drawing.Point(255, 82);
            this.panelEx.Name = "panelEx";
            this.panelEx.Padding = new System.Windows.Forms.Padding(3);
            this.panelEx.Size = new System.Drawing.Size(245, 267);
            this.panelEx.TabIndex = 3;
            // 
            // buttonEx2
            // 
            this.buttonEx2.BackColor = System.Drawing.Color.Red;
            this.buttonEx2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEx2.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEx2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonEx2.Location = new System.Drawing.Point(10, 156);
            this.buttonEx2.Name = "buttonEx2";
            this.buttonEx2.Size = new System.Drawing.Size(231, 43);
            this.buttonEx2.TabIndex = 3;
            this.buttonEx2.Text = "Zi eveniment unic";
            this.buttonEx2.UseVisualStyleBackColor = false;
            // 
            // buttonex3
            // 
            this.buttonex3.BackColor = System.Drawing.Color.DarkOrange;
            this.buttonex3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonex3.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonex3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonex3.Location = new System.Drawing.Point(9, 205);
            this.buttonex3.Name = "buttonex3";
            this.buttonex3.Size = new System.Drawing.Size(231, 46);
            this.buttonex3.TabIndex = 2;
            this.buttonex3.Text = "Zi eveniment repetabil";
            this.buttonex3.UseVisualStyleBackColor = false;
            // 
            // buttonEx1
            // 
            this.buttonEx1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(69)))), ((int)(((byte)(162)))), ((int)(((byte)(158)))));
            this.buttonEx1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEx1.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEx1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonEx1.Location = new System.Drawing.Point(10, 105);
            this.buttonEx1.Name = "buttonEx1";
            this.buttonEx1.Size = new System.Drawing.Size(231, 45);
            this.buttonEx1.TabIndex = 1;
            this.buttonEx1.Text = "Zi libera";
            this.buttonEx1.UseVisualStyleBackColor = false;
            // 
            // panelEx1
            // 
            this.panelEx1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.panelEx1.Controls.Add(this.labelExSus);
            this.panelEx1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEx1.Location = new System.Drawing.Point(3, 3);
            this.panelEx1.Name = "panelEx1";
            this.panelEx1.Size = new System.Drawing.Size(237, 64);
            this.panelEx1.TabIndex = 0;
            // 
            // labelExSus
            // 
            this.labelExSus.AutoSize = true;
            this.labelExSus.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelExSus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.labelExSus.Location = new System.Drawing.Point(83, 12);
            this.labelExSus.Name = "labelExSus";
            this.labelExSus.Size = new System.Drawing.Size(81, 28);
            this.labelExSus.TabIndex = 0;
            this.labelExSus.Text = "Exemplu";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.label6.Location = new System.Drawing.Point(8, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(308, 28);
            this.label6.TabIndex = 2;
            this.label6.Text = "Selecteaza culoarea pe care o schimbi";
            // 
            // comboBoxCulori
            // 
            this.comboBoxCulori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCulori.FormattingEnabled = true;
            this.comboBoxCulori.Items.AddRange(new object[] {
            "Culoare de fundal",
            "Culoare meniuri",
            "Culoare zi libera in calendar",
            "Culoare eveniment unic in calendar",
            "Culoare eveniment repetabil in calendar",
            "Culoare scris meniuri",
            "Culoare scris butoane calendar"});
            this.comboBoxCulori.Location = new System.Drawing.Point(322, 31);
            this.comboBoxCulori.Name = "comboBoxCulori";
            this.comboBoxCulori.Size = new System.Drawing.Size(187, 21);
            this.comboBoxCulori.TabIndex = 1;
            // 
            // buttonSelectareCulori
            // 
            this.buttonSelectareCulori.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.buttonSelectareCulori.FlatAppearance.BorderSize = 2;
            this.buttonSelectareCulori.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSelectareCulori.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSelectareCulori.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonSelectareCulori.Location = new System.Drawing.Point(13, 82);
            this.buttonSelectareCulori.Name = "buttonSelectareCulori";
            this.buttonSelectareCulori.Size = new System.Drawing.Size(224, 44);
            this.buttonSelectareCulori.TabIndex = 0;
            this.buttonSelectareCulori.Text = "Selectare culoare";
            this.buttonSelectareCulori.UseVisualStyleBackColor = false;
            this.buttonSelectareCulori.Click += new System.EventHandler(this.buttonSelectareCulori_Click);
            // 
            // panelUrmarire
            // 
            this.panelUrmarire.Controls.Add(this.button2);
            this.panelUrmarire.Controls.Add(this.label5);
            this.panelUrmarire.Controls.Add(this.label4);
            this.panelUrmarire.Controls.Add(this.buttonUrmareste);
            this.panelUrmarire.Controls.Add(this.comboBoxNume);
            this.panelUrmarire.Controls.Add(this.comboBoxCategoria);
            this.panelUrmarire.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelUrmarire.Location = new System.Drawing.Point(172, 57);
            this.panelUrmarire.Name = "panelUrmarire";
            this.panelUrmarire.Size = new System.Drawing.Size(512, 355);
            this.panelUrmarire.TabIndex = 3;
            this.panelUrmarire.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.button2.FlatAppearance.BorderSize = 3;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.button2.Location = new System.Drawing.Point(279, 295);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(169, 59);
            this.button2.TabIndex = 17;
            this.button2.Text = "Nu mai urmari";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.label5.Location = new System.Drawing.Point(21, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(251, 33);
            this.label5.TabIndex = 9;
            this.label5.Text = "Selecteaza indrumatorul";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.label4.Location = new System.Drawing.Point(21, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(209, 33);
            this.label4.TabIndex = 8;
            this.label4.Text = "Selecteaza categoria";
            // 
            // buttonUrmareste
            // 
            this.buttonUrmareste.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.buttonUrmareste.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonUrmareste.FlatAppearance.BorderSize = 3;
            this.buttonUrmareste.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUrmareste.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUrmareste.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonUrmareste.Location = new System.Drawing.Point(52, 295);
            this.buttonUrmareste.Name = "buttonUrmareste";
            this.buttonUrmareste.Size = new System.Drawing.Size(169, 59);
            this.buttonUrmareste.TabIndex = 7;
            this.buttonUrmareste.Text = "Urmareste";
            this.buttonUrmareste.UseVisualStyleBackColor = false;
            this.buttonUrmareste.Click += new System.EventHandler(this.buttonUrmareste_Click);
            // 
            // comboBoxNume
            // 
            this.comboBoxNume.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxNume.FormattingEnabled = true;
            this.comboBoxNume.Location = new System.Drawing.Point(293, 157);
            this.comboBoxNume.Name = "comboBoxNume";
            this.comboBoxNume.Size = new System.Drawing.Size(207, 21);
            this.comboBoxNume.TabIndex = 1;
            this.comboBoxNume.SelectedIndexChanged += new System.EventHandler(this.comboBoxNume_SelectedIndexChanged);
            // 
            // comboBoxCategoria
            // 
            this.comboBoxCategoria.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCategoria.FormattingEnabled = true;
            this.comboBoxCategoria.Items.AddRange(new object[] {
            "Informatica",
            "Muzica",
            "Stiinte",
            "Sport",
            "Lingvistica/Lectura",
            "Altele"});
            this.comboBoxCategoria.Location = new System.Drawing.Point(293, 50);
            this.comboBoxCategoria.Name = "comboBoxCategoria";
            this.comboBoxCategoria.Size = new System.Drawing.Size(207, 21);
            this.comboBoxCategoria.TabIndex = 0;
            this.comboBoxCategoria.SelectedIndexChanged += new System.EventHandler(this.comboBoxCategoria_SelectedIndexChanged);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.ClientSize = new System.Drawing.Size(684, 412);
            this.Controls.Add(this.panelPaleteCulori);
            this.Controls.Add(this.panelCulori);
            this.Controls.Add(this.panelUrmarire);
            this.Controls.Add(this.panelCalendar);
            this.Controls.Add(this.panelAdaugare);
            this.Controls.Add(this.panelSus);
            this.Controls.Add(this.panelStanga);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormPrincipal";
            this.panelStanga.ResumeLayout(false);
            this.panelSus.ResumeLayout(false);
            this.panelSus.PerformLayout();
            this.panelCalendar.ResumeLayout(false);
            this.panelCalendar.PerformLayout();
            this.panelPaleteCulori.ResumeLayout(false);
            this.panelPaleteCulori.PerformLayout();
            this.panelAdaugare.ResumeLayout(false);
            this.panelAdaugare.PerformLayout();
            this.panelCulori.ResumeLayout(false);
            this.panelCulori.PerformLayout();
            this.panelEx.ResumeLayout(false);
            this.panelEx1.ResumeLayout(false);
            this.panelEx1.PerformLayout();
            this.panelUrmarire.ResumeLayout(false);
            this.panelUrmarire.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelStanga;
        private System.Windows.Forms.Panel panelSus;
        private System.Windows.Forms.Label labelNumeUtilizator;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button buttonMinimise;
        private System.Windows.Forms.Button buttonCulori;
        private System.Windows.Forms.Button buttonAdauga;
        private System.Windows.Forms.Button buttonMeniu;
        private System.Windows.Forms.Button buttonCalendar;
        private System.Windows.Forms.Panel panelCalendar;
        private System.Windows.Forms.Button buttonArataCalendarul;
        private System.Windows.Forms.Button buttonMareLuna;
        private System.Windows.Forms.Button buttonMareAn;
        private System.Windows.Forms.Button buttonMicAn;
        private System.Windows.Forms.Button buttonMicLuna;
        private System.Windows.Forms.Label labelAn;
        private System.Windows.Forms.Label labelLuna;
        private System.Windows.Forms.Panel panelAdaugare;
        private System.Windows.Forms.CheckedListBox checkedListBoxZile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxDetalii;
        private System.Windows.Forms.TextBox textBoxTitlu;
        private System.Windows.Forms.RadioButton radioButtonNuSeRepeta;
        private System.Windows.Forms.RadioButton radioButtonSeRepeta;
        private System.Windows.Forms.Button buttonAdaugare;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelCulori;
        private System.Windows.Forms.Button buttonSelectareCulori;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.TextBox textBoxTitluSchema;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonIntrodu;
        private System.Windows.Forms.Panel panelEx;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxCulori;
        private System.Windows.Forms.Button buttonEx2;
        private System.Windows.Forms.Button buttonex3;
        private System.Windows.Forms.Button buttonEx1;
        private System.Windows.Forms.Panel panelEx1;
        private System.Windows.Forms.Label labelExSus;
        private System.Windows.Forms.Panel panelPaleteCulori;
        private System.Windows.Forms.Button buttonAplica;
        private System.Windows.Forms.Label labelSelecteazaPaleta;
        private System.Windows.Forms.ComboBox comboBoxPaleta;
        private System.Windows.Forms.Button buttonSelecteazaPaleta;
        private System.Windows.Forms.Button buttonAdaugaPaleta;
        private System.Windows.Forms.ComboBox comboBoxCategorie;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelUrmarire;
        private System.Windows.Forms.ComboBox comboBoxNume;
        private System.Windows.Forms.ComboBox comboBoxCategoria;
        private System.Windows.Forms.Button buttonUrmareste;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
    }
}