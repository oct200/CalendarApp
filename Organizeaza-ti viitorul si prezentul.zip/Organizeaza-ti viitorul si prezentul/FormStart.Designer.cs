﻿namespace Viitorul_este_acum
{
    partial class FormStart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStart));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.labelNumeAutentificare = new System.Windows.Forms.Label();
            this.labelParolaAutentificare = new System.Windows.Forms.Label();
            this.textBoxNumeAutentificare = new System.Windows.Forms.TextBox();
            this.textBoxParolaAutentificare = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttonAutentificare = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonMinimise = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonHide = new System.Windows.Forms.Button();
            this.radioButtonElev = new System.Windows.Forms.RadioButton();
            this.radioButtonProf = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(12)))), ((int)(((byte)(16)))));
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(0, 347);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(684, 65);
            this.panel1.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe Print", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.button2.Location = new System.Drawing.Point(333, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(351, 65);
            this.button2.TabIndex = 1;
            this.button2.Text = "Înregistrare";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(330, 65);
            this.button1.TabIndex = 0;
            this.button1.Text = "Autentificare";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // labelNumeAutentificare
            // 
            this.labelNumeAutentificare.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelNumeAutentificare.AutoSize = true;
            this.labelNumeAutentificare.BackColor = System.Drawing.Color.Transparent;
            this.labelNumeAutentificare.Font = new System.Drawing.Font("Segoe Print", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumeAutentificare.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.labelNumeAutentificare.Location = new System.Drawing.Point(21, 137);
            this.labelNumeAutentificare.Name = "labelNumeAutentificare";
            this.labelNumeAutentificare.Size = new System.Drawing.Size(282, 47);
            this.labelNumeAutentificare.TabIndex = 1;
            this.labelNumeAutentificare.Text = "nume de utilizator:";
            // 
            // labelParolaAutentificare
            // 
            this.labelParolaAutentificare.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelParolaAutentificare.AutoSize = true;
            this.labelParolaAutentificare.BackColor = System.Drawing.Color.Transparent;
            this.labelParolaAutentificare.Font = new System.Drawing.Font("Segoe Print", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelParolaAutentificare.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.labelParolaAutentificare.Location = new System.Drawing.Point(185, 184);
            this.labelParolaAutentificare.Name = "labelParolaAutentificare";
            this.labelParolaAutentificare.Size = new System.Drawing.Size(114, 47);
            this.labelParolaAutentificare.TabIndex = 2;
            this.labelParolaAutentificare.Text = "parola:";
            // 
            // textBoxNumeAutentificare
            // 
            this.textBoxNumeAutentificare.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxNumeAutentificare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.textBoxNumeAutentificare.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxNumeAutentificare.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxNumeAutentificare.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.textBoxNumeAutentificare.Location = new System.Drawing.Point(309, 140);
            this.textBoxNumeAutentificare.Name = "textBoxNumeAutentificare";
            this.textBoxNumeAutentificare.Size = new System.Drawing.Size(259, 38);
            this.textBoxNumeAutentificare.TabIndex = 3;
            this.textBoxNumeAutentificare.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxParolaAutentificare
            // 
            this.textBoxParolaAutentificare.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxParolaAutentificare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.textBoxParolaAutentificare.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxParolaAutentificare.Font = new System.Drawing.Font("Segoe Print", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxParolaAutentificare.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.textBoxParolaAutentificare.Location = new System.Drawing.Point(309, 188);
            this.textBoxParolaAutentificare.Name = "textBoxParolaAutentificare";
            this.textBoxParolaAutentificare.PasswordChar = '*';
            this.textBoxParolaAutentificare.Size = new System.Drawing.Size(259, 38);
            this.textBoxParolaAutentificare.TabIndex = 4;
            this.textBoxParolaAutentificare.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(310, 184);
            this.panel2.MaximumSize = new System.Drawing.Size(5000, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(258, 1);
            this.panel2.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(305, 232);
            this.panel3.MaximumSize = new System.Drawing.Size(5000, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(263, 1);
            this.panel3.TabIndex = 6;
            // 
            // buttonAutentificare
            // 
            this.buttonAutentificare.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.buttonAutentificare.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.buttonAutentificare.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonAutentificare.FlatAppearance.BorderSize = 3;
            this.buttonAutentificare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAutentificare.Font = new System.Drawing.Font("Segoe Print", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAutentificare.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.buttonAutentificare.Location = new System.Drawing.Point(231, 292);
            this.buttonAutentificare.Name = "buttonAutentificare";
            this.buttonAutentificare.Size = new System.Drawing.Size(206, 49);
            this.buttonAutentificare.TabIndex = 7;
            this.buttonAutentificare.Text = "Intră în cont";
            this.buttonAutentificare.UseVisualStyleBackColor = false;
            this.buttonAutentificare.Click += new System.EventHandler(this.buttonAutentificare_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.panel4.Controls.Add(this.buttonX);
            this.panel4.Controls.Add(this.buttonMinimise);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(684, 134);
            this.panel4.TabIndex = 8;
            // 
            // buttonX
            // 
            this.buttonX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonX.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonX.ForeColor = System.Drawing.Color.Black;
            this.buttonX.Location = new System.Drawing.Point(648, 3);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(20, 22);
            this.buttonX.TabIndex = 11;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = true;
            this.buttonX.Click += new System.EventHandler(this.buttonX_Click);
            // 
            // buttonMinimise
            // 
            this.buttonMinimise.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonMinimise.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonMinimise.ForeColor = System.Drawing.Color.Black;
            this.buttonMinimise.Location = new System.Drawing.Point(622, 3);
            this.buttonMinimise.Name = "buttonMinimise";
            this.buttonMinimise.Size = new System.Drawing.Size(20, 22);
            this.buttonMinimise.TabIndex = 10;
            this.buttonMinimise.Text = "-";
            this.buttonMinimise.UseVisualStyleBackColor = true;
            this.buttonMinimise.Click += new System.EventHandler(this.buttonMinimise_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(198)))), ((int)(((byte)(199)))));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.MaximumSize = new System.Drawing.Size(640, 2000);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(640, 112);
            this.label1.TabIndex = 9;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // buttonHide
            // 
            this.buttonHide.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHide.Location = new System.Drawing.Point(158, 196);
            this.buttonHide.Name = "buttonHide";
            this.buttonHide.Size = new System.Drawing.Size(21, 32);
            this.buttonHide.TabIndex = 9;
            this.buttonHide.Text = "👁️";
            this.buttonHide.UseVisualStyleBackColor = true;
            this.buttonHide.Click += new System.EventHandler(this.buttonHide_Click);
            // 
            // radioButtonElev
            // 
            this.radioButtonElev.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radioButtonElev.AutoSize = true;
            this.radioButtonElev.Checked = true;
            this.radioButtonElev.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonElev.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.radioButtonElev.Location = new System.Drawing.Point(158, 254);
            this.radioButtonElev.Name = "radioButtonElev";
            this.radioButtonElev.Size = new System.Drawing.Size(129, 32);
            this.radioButtonElev.TabIndex = 10;
            this.radioButtonElev.TabStop = true;
            this.radioButtonElev.Text = "Cont de elev";
            this.radioButtonElev.UseVisualStyleBackColor = true;
            this.radioButtonElev.Visible = false;
            // 
            // radioButtonProf
            // 
            this.radioButtonProf.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radioButtonProf.AutoSize = true;
            this.radioButtonProf.Font = new System.Drawing.Font("Segoe Print", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonProf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(40)))), ((int)(((byte)(51)))));
            this.radioButtonProf.Location = new System.Drawing.Point(375, 254);
            this.radioButtonProf.Name = "radioButtonProf";
            this.radioButtonProf.Size = new System.Drawing.Size(193, 32);
            this.radioButtonProf.TabIndex = 11;
            this.radioButtonProf.Text = "Cont de îndrumator";
            this.radioButtonProf.UseVisualStyleBackColor = true;
            this.radioButtonProf.Visible = false;
            // 
            // FormStart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(252)))), ((int)(((byte)(241)))));
            this.ClientSize = new System.Drawing.Size(684, 412);
            this.Controls.Add(this.radioButtonProf);
            this.Controls.Add(this.radioButtonElev);
            this.Controls.Add(this.buttonHide);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.buttonAutentificare);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.textBoxParolaAutentificare);
            this.Controls.Add(this.textBoxNumeAutentificare);
            this.Controls.Add(this.labelParolaAutentificare);
            this.Controls.Add(this.labelNumeAutentificare);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormStart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormStart";
            this.Load += new System.EventHandler(this.FormStart_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labelNumeAutentificare;
        private System.Windows.Forms.Label labelParolaAutentificare;
        private System.Windows.Forms.TextBox textBoxNumeAutentificare;
        private System.Windows.Forms.TextBox textBoxParolaAutentificare;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttonAutentificare;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonHide;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button buttonMinimise;
        private System.Windows.Forms.RadioButton radioButtonElev;
        private System.Windows.Forms.RadioButton radioButtonProf;
    }
}

