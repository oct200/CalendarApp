﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Viitorul_este_acum
{
    public partial class FormProgramZi : Form
    {
        Label[] lTitlu;
        Label[] lDetalii;
        Label[] lOre;
        Label[] lCategorii;
        Button[] b;
        Button bAdauga;

        int wPanel;

        public void ColorareForm()
        {
            this.BackColor = VariabileGlobale.culori[0];
            panelJos.BackColor = VariabileGlobale.culori[0];

            panelSus.BackColor = VariabileGlobale.culori[1];

            buttonReincarca.ForeColor = VariabileGlobale.culori[5];

            labelZiua.ForeColor = VariabileGlobale.culori[5];
        }

        public void ButtonStergere_Click(object sender , EventArgs e , int idEveniment)
        {
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand stergere = new SqlCommand("DELETE FROM TabelEvenimente WHERE IdEveniment ='" + idEveniment + "'", conexiune);
            stergere.ExecuteNonQuery();
            conexiune.Close();
            FormProgramZi fpz = new FormProgramZi();
            this.Hide();
            fpz.ShowDialog();
        }

        public void Program()
        {
            
            lTitlu = new Label[50];
            lDetalii = new Label[50];
            lCategorii = new Label[50];
            b = new Button[50];
            
            labelZiua.Text = "" + VariabileGlobale.dataCurenta.Day + " " + VariabileGlobale.dataCurenta.Month + " " + VariabileGlobale.dataCurenta.Year;
            int x = (panelSus.Width - labelZiua.Width) / 2;
            labelZiua.Location = new Point(x, labelZiua.Location.Y);

            int ziuaSaptamanii = Convert.ToInt32(VariabileGlobale.dataCurenta.DayOfWeek);
            if (ziuaSaptamanii == 0)
                ziuaSaptamanii = 7;
            
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            int hPanel = 10;
            int ok1 = 0;
            int nr = 0;
            for (int q = 0; q < VariabileGlobale.m; q++)
            {
                int nr2 = 0 , nraux = nr;
                int ok = 0;
                SqlCommand selectare = new SqlCommand("SELECT Titlu , Descriere , IdEveniment FROM TabelEvenimente WHERE ((ZiuaLunii = '" + VariabileGlobale.dataCurenta.Day + "' AND Luna = '" + VariabileGlobale.dataCurenta.Month + "' AND An = '" + VariabileGlobale.dataCurenta.Year + "') OR ZiuaSaptamanii = '" + ziuaSaptamanii + "') AND (Categorie = '" + VariabileGlobale.categorii[q] + "' AND NumeCurs = '" + VariabileGlobale.indrumatori[q]+"')", conexiune);
                SqlDataReader dr = selectare.ExecuteReader();

                int[] idEveniment = new int[50];
                
                while (dr.Read())
                {
                    ok = 1;
                    ok1 = 1;
                    lTitlu[nr] = new Label();
                    lDetalii[nr] = new Label();
                    b[nr] = new Button();

                    lTitlu[nr].AutoSize = true;
                    lTitlu[nr].Text = Convert.ToString(dr["Titlu"]);

                    lDetalii[nr].AutoSize = true;
                    lDetalii[nr].Text = Convert.ToString(dr["Descriere"]);

                    idEveniment[nr] = Convert.ToInt32(dr["IdEveniment"]);
                    nr++;
                    nr2++;
                }
                dr.Close();

                if (ok == 1)
                {
                    lCategorii[q] = new Label();
                    lCategorii[q].Anchor = (AnchorStyles.Top);
                    lCategorii[q].AutoSize = true;
                    lCategorii[q].Font = new Font("Segoe Print", 18, FontStyle.Bold);
                    lCategorii[q].ForeColor = VariabileGlobale.culori[6];
                    lCategorii[q].Name = "labelCategorii" + q;
                    lCategorii[q].Text = VariabileGlobale.indrumatori[q] + " - " + VariabileGlobale.categorii[q];
                    this.panelJos.Controls.Add(lCategorii[q]);
                    if (wPanel - lCategorii[q].Size.Width / 2 >= 0)
                        lCategorii[q].Location = new Point(wPanel - lCategorii[q].Size.Width / 2, hPanel);
                    else
                        lCategorii[q].Location = new Point(0, hPanel);
                    hPanel += lCategorii[q].Height + 5;



                    for (int i = 0; i < nr2; i++)
                    {
                        lTitlu[nraux +i].Font = new Font("Segoe Print", 16, FontStyle.Bold);
                        lTitlu[nraux + i].Anchor = (AnchorStyles.Top);
                        lTitlu[nraux +i].ForeColor = VariabileGlobale.culori[6];
                        lTitlu[nraux +i].Name = "labelTitlu" + nraux + i;
                        this.panelJos.Controls.Add(lTitlu[nraux + i]);
                        if (wPanel - lTitlu[nraux +i].Size.Width / 2 >= 0)
                            lTitlu[nraux +i].Location = new Point(wPanel - lTitlu[nraux +i].Size.Width / 2, hPanel);
                        else
                            lTitlu[nraux + i].Location = new Point(0, hPanel);


                        lDetalii[nraux + i].Font = new Font("Segoe Print", 10, FontStyle.Bold);
                        lDetalii[nraux + i].Anchor = (AnchorStyles.Top );
                        lDetalii[nraux + i].ForeColor = VariabileGlobale.culori[6];
                        lDetalii[nraux + i].Name = "labelDetalii" + nraux + i;
                        lDetalii[nraux + i].MaximumSize = new Size(this.Width - 25, 3000);
                        this.panelJos.Controls.Add(lDetalii[nraux + i]);
                        if (wPanel - lDetalii[nraux + i].Size.Width / 2 >= 0)
                            lDetalii[nraux + i].Location = new Point(wPanel - lDetalii[nraux + i].Size.Width / 2, lTitlu[nraux + i].Location.Y + lTitlu[nraux + i].Height);
                        else
                            lDetalii[nraux + i].Location = new Point(0, lTitlu[nraux + i].Location.Y + lTitlu[nraux + i].Height);


                        if (VariabileGlobale.EsteElev == 0)
                        {
                            b[nraux + i].AutoSize = true;
                            b[nraux + i].Font = new Font("Segoe Print", 10, FontStyle.Bold);
                            b[nraux + i].Anchor = (AnchorStyles.Top );
                            b[nraux + i].FlatStyle = FlatStyle.Flat;
                            b[nraux + i].BackColor = VariabileGlobale.culori[1];
                            b[nraux + i].ForeColor = VariabileGlobale.culori[5];
                            b[nraux + i].Text = "ELIMINA";
                            b[nraux + i].Name = "button" + nraux + i;
                            b[nraux + i].Size = new Size(75, 35);
                            b[nraux + i].Location = new Point(lTitlu[nraux + i].Location.X + lTitlu[nraux + i].Width + 5, lTitlu[nraux + i].Location.Y - 3);
                            int aux = idEveniment[nraux + i];
                            b[nraux + i].Click += delegate (object sender1, EventArgs e1)
                            {
                                ButtonStergere_Click(sender1, e1, aux);
                            };
                            this.panelJos.Controls.Add(b[nraux + i]);
                        }
                        hPanel += lTitlu[i].Height + lDetalii[i].Height + 30;
                    }
                }
            }
            if (ok1 == 0)
            {
                Label lZiLibera = new Label();
                lZiLibera.AutoSize = true;
                lZiLibera.TextAlign = ContentAlignment.MiddleCenter;
                lZiLibera.Font = new Font("Segoe Print", 24, FontStyle.Bold);
                lZiLibera.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom);
                lZiLibera.ForeColor = VariabileGlobale.culori[6];
                lZiLibera.BackColor = VariabileGlobale.culori[0];
                lZiLibera.Name = "labelZiLibera";
                lZiLibera.Text = "ZI LIBERA :)";
                lZiLibera.Location = new Point(wPanel, panelJos.Height / 2);
                this.panelJos.Controls.Add(lZiLibera);
                lZiLibera.Location = new Point(wPanel - lZiLibera.Width / 2, panelJos.Height / 2 - lZiLibera.Height / 2);
            }
            if (VariabileGlobale.EsteElev == 0)
            {
                bAdauga = new Button();
                bAdauga.Font = new Font("Segoe Print", 10, FontStyle.Bold);
                bAdauga.FlatStyle = FlatStyle.Flat;
                bAdauga.BackColor = VariabileGlobale.culori[1];
                bAdauga.ForeColor = VariabileGlobale.culori[5];
                bAdauga.Text = "Adauga un eveniment in aceasta zi";
                ///bAdauga.Anchor = (AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
                bAdauga.Dock = DockStyle.Bottom;
                bAdauga.Name = "buttonAdauga";
                bAdauga.Size = new Size(panelJos.Width , 50);
                if (hPanel + 50 > panelJos.Height)
                {
                    bAdauga.Location = new Point(0, hPanel+50);
                }
                else
                {
                    bAdauga.Location = new Point(0, panelJos.Height - 50);
                }
                bAdauga.Click += new EventHandler(BAdauga_Click);
                this.panelJos.Controls.Add(bAdauga);
            }
        }

        private void BAdauga_Click(object sender , EventArgs e)
        {
            FormAdaugare fa = new FormAdaugare();
            fa.ShowDialog();
        }
        public FormProgramZi()
        {
            InitializeComponent();
            wPanel = panelJos.Width/2;
            ColorareForm();
            Program();
            if (VariabileGlobale.EsteElev == 1)
                buttonReincarca.Visible = false;
            else
                buttonReincarca.Visible = true;
        }

        private void buttonX_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void buttonMinimise_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void FormProgramZi_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormProgramZi fpz = new FormProgramZi();
            fpz.ShowDialog();
            this.Hide();
        }

        private void panelJos_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
