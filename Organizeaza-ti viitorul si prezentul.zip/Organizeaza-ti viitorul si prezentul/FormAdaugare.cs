﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Viitorul_este_acum
{
    public partial class FormAdaugare : Form
    {

        private void ColorareForm()
        {
            this.BackColor = VariabileGlobale.culori[0];
            panelTot.BackColor = VariabileGlobale.culori[0];
            textBoxDetalii.BackColor = VariabileGlobale.culori[0];
            textBoxTitlu.BackColor = VariabileGlobale.culori[0];

            label1.ForeColor = VariabileGlobale.culori[6];
            label2.ForeColor = VariabileGlobale.culori[6];
            label3.ForeColor = VariabileGlobale.culori[6];
            textBoxDetalii.ForeColor = VariabileGlobale.culori[6];
            textBoxTitlu.ForeColor = VariabileGlobale.culori[6];


            buttonAdaugare.BackColor = VariabileGlobale.culori[1];
            buttonAdaugare.ForeColor = VariabileGlobale.culori[5];


        }
        public FormAdaugare()
        {
            InitializeComponent();
            buttonAdaugare.Location = new Point(0, panelTot.Height - 50);
            buttonAdaugare.Size = new Size(panelTot.Width, 50);
            ColorareForm();
        }

        private void buttonAdaugare_Click(object sender, EventArgs e)
        {
            if (textBoxDetalii.Text == "" || textBoxTitlu.Text == "" || comboBoxCategoria.Text == "")
            {
                MessageBox.Show("Introduceti toate datele!");
                return;
            }
            string titlu = textBoxTitlu.Text, detalii = textBoxDetalii.Text;
            DateTime dt = VariabileGlobale.dataCurenta;
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand insertie = new SqlCommand("INSERT INTO TabelEvenimente ( Titlu , Descriere , ZiuaLunii , Luna , An , Categorie , NumeCurs , SeRepeta) VALUES ('" + titlu + "', '" + detalii + "' , '" + dt.Day + "' , '" + dt.Month + "', '" + dt.Year + "', '" + comboBoxCategoria.Text + "', '" + VariabileGlobale.numeCurent + "', 0)", conexiune);
            insertie.ExecuteNonQuery();
            MessageBox.Show("Evenimentul cu titlul " + titlu + " a fost adaugat in data de " + dt.Day + ", " + Convert.ToInt32(dt.Month) + ", " + dt.Year);
            conexiune.Close();
                    
        }

        private void panelTot_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
