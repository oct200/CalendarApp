﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Viitorul_este_acum
{
    public partial class FormPrincipal : Form
    {
        string[] luni = {"" , "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie" };
        int luna = 3;
        int an = 2022 , ok =0;
        bool ok_combobox = false;

        DateTime dt = new DateTime();        
        Button[,] butoaneCalendar;

        private void IncarcaCulori(int x)
        {
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand selectie = new SqlCommand("SELECT * FROM TabelCulori WHERE IdColorScheme = '" + x + "'", conexiune);
            SqlDataReader dr = selectie.ExecuteReader();
            if (dr.Read())
            {
                for (int i = 0; i < 7; i++)
                    VariabileGlobale.culori[i] = ColorTranslator.FromHtml(Convert.ToString(dr[i + 3]));
            }
            dr.Close();
            conexiune.Close();
        }

        private void ColorareAplicatie()
        {
            panelAdaugare.BackColor = VariabileGlobale.culori[0];
            panelCalendar.BackColor = VariabileGlobale.culori[0];
            panelUrmarire.BackColor = VariabileGlobale.culori[0];
            panelCulori.BackColor = VariabileGlobale.culori[0];
            panelPaleteCulori.BackColor = VariabileGlobale.culori[0];
            label1.BackColor = VariabileGlobale.culori[0];
            label2.BackColor = VariabileGlobale.culori[0];
            label3.BackColor = VariabileGlobale.culori[0];
            label4.BackColor = VariabileGlobale.culori[0];
            label5.BackColor = VariabileGlobale.culori[0];
            label6.BackColor = VariabileGlobale.culori[0];
            label7.BackColor = VariabileGlobale.culori[0];
            labelAn.BackColor = VariabileGlobale.culori[0];
            labelLuna.BackColor = VariabileGlobale.culori[0];
            labelSelecteazaPaleta.BackColor = VariabileGlobale.culori[0];
            textBoxDetalii.BackColor = VariabileGlobale.culori[0];
            textBoxTitlu.BackColor = VariabileGlobale.culori[0];
            checkedListBoxZile.BackColor = VariabileGlobale.culori[0];
            this.BackColor = VariabileGlobale.culori[0];


            panelSus.BackColor = VariabileGlobale.culori[1];
            panelStanga.BackColor = VariabileGlobale.culori[1];
            buttonCulori.BackColor = VariabileGlobale.culori[1];
            buttonAdauga.BackColor = VariabileGlobale.culori[1];
            buttonMeniu.BackColor = VariabileGlobale.culori[1];
            buttonCalendar.BackColor = VariabileGlobale.culori[1];
            buttonArataCalendarul.BackColor = VariabileGlobale.culori[1];
            buttonMareLuna.BackColor = VariabileGlobale.culori[1];
            buttonMareAn.BackColor = VariabileGlobale.culori[1];
            buttonMicAn.BackColor = VariabileGlobale.culori[1];
            buttonMicLuna.BackColor = VariabileGlobale.culori[1];

            panelSus.ForeColor = VariabileGlobale.culori[5];
            panelStanga.ForeColor = VariabileGlobale.culori[5];
            buttonCulori.ForeColor = VariabileGlobale.culori[5];
            buttonAdauga.ForeColor = VariabileGlobale.culori[5];
            buttonMeniu.ForeColor = VariabileGlobale.culori[5];
            buttonCalendar.ForeColor = VariabileGlobale.culori[5];
            buttonArataCalendarul.ForeColor = VariabileGlobale.culori[5];
            buttonMareLuna.ForeColor = VariabileGlobale.culori[5];
            buttonMareAn.ForeColor = VariabileGlobale.culori[5];
            buttonMicAn.ForeColor = VariabileGlobale.culori[5];
            buttonMicLuna.ForeColor = VariabileGlobale.culori[5];
            buttonUrmareste.ForeColor = VariabileGlobale.culori[5];
            button2.ForeColor = VariabileGlobale.culori[5];
            labelNumeUtilizator.ForeColor = VariabileGlobale.culori[5];

            label1.ForeColor = VariabileGlobale.culori[6];
            label2.ForeColor = VariabileGlobale.culori[6];
            label3.ForeColor = VariabileGlobale.culori[6];
            label4.ForeColor = VariabileGlobale.culori[6];
            label5.ForeColor = VariabileGlobale.culori[6];
            label6.ForeColor = VariabileGlobale.culori[6];
            label7.ForeColor = VariabileGlobale.culori[6];
            labelAn.ForeColor = VariabileGlobale.culori[6];
            labelLuna.ForeColor = VariabileGlobale.culori[6];
            labelSelecteazaPaleta.ForeColor = VariabileGlobale.culori[6];
            textBoxDetalii.ForeColor = VariabileGlobale.culori[6];
            textBoxTitlu.ForeColor = VariabileGlobale.culori[6];
            checkedListBoxZile.ForeColor = VariabileGlobale.culori[6];
        }

        private void Urmariri()
        {
            for (int i = 0; i < VariabileGlobale.m; i++)
            {
                VariabileGlobale.indrumatori[VariabileGlobale.m] = "";
                VariabileGlobale.categorii[VariabileGlobale.m] = "";
            }
            VariabileGlobale.m = 0;
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand selectare = new SqlCommand("SELECT * FROM TabelUrmariri WHERE Id_Utilizator = '" + VariabileGlobale.idCurent + "'", conexiune);
            SqlDataReader dr = selectare.ExecuteReader();
            while(dr.Read())
            {
                VariabileGlobale.indrumatori[VariabileGlobale.m] = Convert.ToString(dr[2]);
                VariabileGlobale.categorii[VariabileGlobale.m] = Convert.ToString(dr[1]);
                VariabileGlobale.m++;
            }
        }

        public FormPrincipal()
        {
            InitializeComponent();
            IncarcaCulori(VariabileGlobale.colorScheme);
            ColorareAplicatie();
            if(VariabileGlobale.EsteElev == 1)
            {
                buttonAdauga.Text = "Urmareste un indrumator";
            }
            else
            {
                buttonAdauga.Text = "Adauga un eveniment";
            }
            Urmariri();
            labelNumeUtilizator.Text = VariabileGlobale.numeCurent;
            int x = panelSus.Width / 2 - labelNumeUtilizator.Width / 2;
            labelNumeUtilizator.Location = new Point(x, labelNumeUtilizator.Location.Y);
            dt = DateTime.Now;
            luna = dt.Month;
        }

        private void buttonX_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonMaximise_Click(object sender, EventArgs e)
        {
           
        }

        private void buttonMinimise_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void buttonCalendar_Click(object sender, EventArgs e)
        {
            panelAdaugare.Visible = false;
            panelUrmarire.Visible = false;
            panelPaleteCulori.Visible = false;
            panelCulori.Visible = false;
            panelCalendar.Visible = true;
            buttonArataCalendarul.PerformClick();
        }

        private void buttonMicLuna_Click(object sender, EventArgs e)
        {
            if(luna == 1)
            {
                luna = 12;
                an--;
                labelAn.Text = "" + an;
                labelLuna.Text = luni[luna];
                return;
            }
            luna--;
            labelLuna.Text = luni[luna];
            labelLuna.Text = luni[luna];
            int x = labelLuna.Location.X + labelLuna.Width + 5;
            buttonMareLuna.Location = new Point(x, buttonMareLuna.Location.Y);
        }

        private void buttonMareLuna_Click(object sender, EventArgs e)
        {
            if (luna == 12)
            {
                luna = 1;
                an++;
                labelAn.Text = "" + an;
                labelLuna.Text = luni[luna];
                return;
            }
            luna++;
            labelLuna.Text = luni[luna];
            int x = labelLuna.Location.X + labelLuna.Width + 5;
            buttonMareLuna.Location = new Point(x, buttonMareLuna.Location.Y);
        }

        private void buttonMareAn_Click(object sender, EventArgs e)
        {
            an++;
            labelAn.Text = "" + an;
        }

        private void buttonMicAn_Click(object sender, EventArgs e)
        {
            an--;
            labelAn.Text = "" + an;
        }

        private void ButonCalendar_Click(object sender , EventArgs e , int ziua , int luna , int anul)
        {
            VariabileGlobale.dataCurenta = new DateTime(an, luna, ziua);
            FormProgramZi fpz = new FormProgramZi();
            fpz.ShowDialog();
        }

        private void panelAdaugare_Paint(object sender, PaintEventArgs e)
        {
        }

        private void panelStanga_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonActivitatiUrmatoare_Click(object sender, EventArgs e)
        {

        }

        private void buttonCulori_Click(object sender, EventArgs e)
        {
            panelEx.BackColor = VariabileGlobale.culori[0];
            panelEx1.BackColor = VariabileGlobale.culori[1];
            buttonEx1.BackColor = VariabileGlobale.culori[2];
            buttonEx2.BackColor = VariabileGlobale.culori[3];
            buttonex3.BackColor = VariabileGlobale.culori[4];
            labelExSus.ForeColor = VariabileGlobale.culori[5];
            labelExSus.BackColor = VariabileGlobale.culori[1];
            buttonEx1.ForeColor = VariabileGlobale.culori[6];
            buttonEx2.ForeColor = VariabileGlobale.culori[6];
            buttonex3.ForeColor = VariabileGlobale.culori[6];

            if (ok == 1)
            {
                for (int i = 0; i < 6; i++)
                    for (int j = 0; j < 7; j++)
                        this.panelCalendar.Controls.Remove(butoaneCalendar[i, j]);
                ok = 0;
            }
            panelCalendar.Visible = false;
            panelAdaugare.Visible = false;
            panelCulori.Visible = false;
            panelPaleteCulori.Visible = true;
        }

        private void buttonAdauga_Click(object sender, EventArgs e)
        {
            if (ok == 1)
            {
                for (int i = 0; i < 6; i++)
                    for (int j = 0; j < 7; j++)
                        this.panelCalendar.Controls.Remove(butoaneCalendar[i, j]);
                ok = 0;
            }
            if (VariabileGlobale.EsteElev == 0)
            {
                panelCalendar.Visible = false;
                panelPaleteCulori.Visible = false;
                panelCulori.Visible = false;
                panelUrmarire.Visible = false;
                panelAdaugare.Visible = true;
            }
            else
            {
                panelCalendar.Visible = false;
                panelPaleteCulori.Visible = false;
                panelCulori.Visible = false;
                panelUrmarire.Visible = true;
                panelAdaugare.Visible = false;
            }
        }

        private void panelSus_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelNumeUtilizator_Click(object sender, EventArgs e)
        {

        }

        private void panelCalendar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelAn_Click(object sender, EventArgs e)
        {

        }

        private void labelLuna_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBoxZile_SelectedIndexChanged(object sender, EventArgs e)
        {
            checkedListBoxZile.ClearSelected();
        }

        private void radioButtonSeRepeta_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonNuSeRepeta_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDownInceput_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDownFinal_ValueChanged(object sender, EventArgs e)
        {

        }

        private void buttonAdaugare_Click(object sender, EventArgs e)
        {
            if(textBoxDetalii.Text == "" || textBoxTitlu.Text=="")
            {
                MessageBox.Show("Introduceti toate datele!");
                return;
            }
            bool ok = false;
            dt = DateTime.Now;
            for(int i = 0; i <= checkedListBoxZile.Items.Count-1; i ++)
                if(checkedListBoxZile.GetItemChecked(i))
                {
                    ok = true;
                    int ziuaSaptamanii = i + 1, ziuaLunii;
                    if (i + 1 >= Convert.ToInt32(dt.DayOfWeek))
                    {
                        ziuaLunii = dt.Day + (i+1-Convert.ToInt32(dt.DayOfWeek));
                    }
                    else
                        ziuaLunii = dt.Day + ((7-Convert.ToInt32(dt.DayOfWeek) + i + 1));
                    int auxLuna = Convert.ToInt32(dt.Month), auxAn = Convert.ToInt32(dt.Year);
                    int zileInLuna = DateTime.DaysInMonth(auxAn, auxLuna);
                    if (ziuaLunii>zileInLuna)
                    {
                        if(auxLuna == 12)
                        {
                            auxAn++;
                            auxLuna = 1;
                            ziuaLunii = ziuaLunii - zileInLuna;
                        }
                        else
                        {
                            auxLuna++;
                            ziuaLunii = ziuaLunii - zileInLuna;
                        }
                    }

                    SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
                    conexiune.Open();
                    if (radioButtonNuSeRepeta.Checked == true)
                    {
                        SqlCommand insertie = new SqlCommand("INSERT INTO TabelEvenimente (Titlu , Descriere , ZiuaLunii , Luna , An , Categorie , NumeCurs , SeRepeta ) VALUES ( '" + textBoxTitlu.Text + "', '" + textBoxDetalii.Text +"' , '" + ziuaLunii + "' , '" + auxLuna + "', '" + auxAn + "', '" + comboBoxCategorie.Text + "' , '" + VariabileGlobale.numeCurent +"' , 0)", conexiune);
                        insertie.ExecuteNonQuery();
                        conexiune.Close();
                    }
                    else
                    {
                        SqlCommand insertie = new SqlCommand("INSERT INTO TabelEvenimente ( ZiuaSaptamanii , Titlu , Descriere , ZiuaLunii , Luna , An , Categorie , NumeCurs , SeRepeta) VALUES ( '"+ ziuaSaptamanii +"' , '" + textBoxTitlu.Text + "', '" + textBoxDetalii.Text + "' , '" + ziuaLunii + "' , '" + auxLuna + "', '" + auxAn + "', '" + comboBoxCategorie.Text + "', '" + VariabileGlobale.numeCurent + "', 1)", conexiune);
                        insertie.ExecuteNonQuery();
                        conexiune.Close();
                    }
                    
                }
            if (ok == false)
                MessageBox.Show("Selectati zilele in care va avea loc evenimentul");
            else
            {
                int ok2 = 1;
                for (int i = 0; i < VariabileGlobale.m; i++)
                    if (VariabileGlobale.indrumatori[i] == VariabileGlobale.numeCurent && VariabileGlobale.categorii[i] == comboBoxCategorie.Text)
                        ok2 = 0; 
                if(ok2 == 1)
                {
                    SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
                    conexiune.Open();
                    SqlCommand insertie = new SqlCommand("INSERT INTO TabelUrmariri VALUES ('" + VariabileGlobale.idCurent + "', '" + comboBoxCategorie.Text + "' , '" + VariabileGlobale.numeCurent + "')", conexiune);
                    insertie.ExecuteNonQuery();
                    VariabileGlobale.indrumatori[VariabileGlobale.m] = VariabileGlobale.numeCurent;
                    VariabileGlobale.categorii[VariabileGlobale.m] = comboBoxCategorie.Text;
                    VariabileGlobale.m++;
                }
                MessageBox.Show("Eveniment adaugat!");
            }
        }

        private void buttonSelectareCulori_Click(object sender, EventArgs e)
        {
            Color culoare = new Color();
            int index = comboBoxCulori.SelectedIndex;
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                VariabileGlobale.culori[index] = colorDialog.Color;
                culoare = colorDialog.Color;
                string codCuloare = ColorTranslator.ToHtml(culoare);

                if (index == 0)
                {
                    panelEx.BackColor = culoare;
                    return;
                }
                if (index == 1)
                {
                    panelEx1.BackColor = culoare;
                    labelExSus.BackColor = culoare;
                    return;
                }
                if (index == 2)
                {
                    buttonEx1.BackColor = culoare;
                    return;
                }
                if (index == 3)
                {
                    buttonEx2.BackColor = culoare;
                    return;
                }
                if (index == 4)
                {
                    buttonex3.BackColor = culoare;
                    return;
                }
                if (index == 5)
                {
                    labelExSus.ForeColor = culoare;
                    return;

                }
                if (index == 6)
                {
                    buttonEx1.ForeColor = culoare;
                    buttonEx2.ForeColor = culoare;
                    buttonex3.ForeColor = culoare;
                    return;
                }
            }
        }

        private void buttonIntrodu_Click(object sender, EventArgs e)
        {
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand insertie = new SqlCommand("INSERT INTO TabelCulori VALUES ( '" + VariabileGlobale.idCurent + "' , '" + textBoxTitluSchema.Text + "' , '" + ColorTranslator.ToHtml(VariabileGlobale.culori[0]) + "' , '" + ColorTranslator.ToHtml(VariabileGlobale.culori[1]) + "' , '" + ColorTranslator.ToHtml(VariabileGlobale.culori[2]) + "' , '" + ColorTranslator.ToHtml(VariabileGlobale.culori[3]) + "' , '" + ColorTranslator.ToHtml(VariabileGlobale.culori[4]) + "' ,'" + ColorTranslator.ToHtml(VariabileGlobale.culori[5]) + "' ,'" + ColorTranslator.ToHtml(VariabileGlobale.culori[6]) + "')", conexiune);
            insertie.ExecuteNonQuery();
                
        }

        private void buttonAdaugaPaleta_Click(object sender, EventArgs e)
        {
            labelSelecteazaPaleta.Visible = false;
            comboBoxPaleta.Visible = false;
            buttonAplica.Visible = false;
            comboBoxPaleta.Items.Clear();
            buttonSelecteazaPaleta.Enabled = true;
            panelAdaugare.Visible = false;
            panelCalendar.Visible = false;
            panelPaleteCulori.Visible = false;
            panelCulori.Visible = true;
        }

        private void buttonSelecteazaPaleta_Click(object sender, EventArgs e)
        {
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand selectie = new SqlCommand("SELECT TitluColorScheme FROM TabelCulori WHERE IdUtilizator = '" + VariabileGlobale.idCurent + "' OR IdUtilizator = 0", conexiune);
            SqlDataReader dr = selectie.ExecuteReader();
            while(dr.Read())
            {
                comboBoxPaleta.Items.Add(Convert.ToString(dr[0]));
            }
            dr.Close();
            conexiune.Close();

            labelSelecteazaPaleta.Visible = true;
            comboBoxPaleta.Visible = true;
            buttonAplica.Visible = true;
            buttonSelecteazaPaleta.Enabled = false;
        }

        private void buttonAplica_Click(object sender, EventArgs e)
        {
            string titlu = comboBoxPaleta.Text;
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand selectare = new SqlCommand("SELECT IdColorScheme FROM TabelCulori WHERE TitluColorScheme= '" + titlu + "'", conexiune);
            SqlDataReader dr = selectare.ExecuteReader();
            if(dr.Read())
            {
                VariabileGlobale.colorScheme = Convert.ToInt32(dr[0]);
            }
            dr.Close();
            SqlCommand update = new SqlCommand("UPDATE TabelUtilizatori SET ColorScheme = '" + VariabileGlobale.colorScheme + "' WHERE IdUtilizator = '" + VariabileGlobale.idCurent + "'", conexiune);
            update.ExecuteNonQuery();
            conexiune.Close();

            comboBoxPaleta.Items.Clear();
            labelSelecteazaPaleta.Visible = false;
            comboBoxPaleta.Visible = false;
            buttonAplica.Visible = false;
            buttonSelecteazaPaleta.Enabled = true;

            FormPrincipal fp = new FormPrincipal();
            this.Hide();
            fp.ShowDialog();
        }

        public void buttonArataCalendarul_Click(object sender, EventArgs e)
        {
            panelAdaugare.Visible = false;
            panelCalendar.Visible = true;
            if (ok == 1)
            {
                for (int i = 0; i < 6; i++)
                    for (int j = 0; j < 7; j++)
                        this.panelCalendar.Controls.Remove(butoaneCalendar[i, j]);
            }
            else
                ok = 1;
            int nr = 1;
            butoaneCalendar = new Button[6, 7];
            DateTime lunaTrecuta;
            if (luna >= 2)
                lunaTrecuta = new DateTime(an, luna - 1, DateTime.DaysInMonth(an, luna - 1));
            else
                lunaTrecuta = new DateTime(an - 1, 12, DateTime.DaysInMonth(an - 1, 12));
            int ultima = Convert.ToInt32(lunaTrecuta.DayOfWeek);
            if (ultima == 7)
                ultima = 0;

            int wb = 0, hb = 0;
            if((ultima + DateTime.DaysInMonth(an, luna) <= 28))
            {
                wb = panelCalendar.Width / 7;
                hb = (panelCalendar.Height - 120) / 4;
            }
            else
                if ((ultima + DateTime.DaysInMonth(an, luna) <= 35) && (ultima + DateTime.DaysInMonth(an, luna) > 28))
                {
                   wb = panelCalendar.Width / 7;
                   hb = (panelCalendar.Height - 120) / 5;
                }
            else
            {
                wb = panelCalendar.Width / 7;
                hb = (panelCalendar.Height - 120) / 6;
            }

            for(int i = 0; i < 6; i ++)
            {
                for(int j = 0; j < 7 && nr <= DateTime.DaysInMonth(an,luna); j ++)
                {
                    butoaneCalendar[i, j] = new Button();
                    if (i > 0 || j >= ultima )
                    {
                        
                        butoaneCalendar[i, j].Size = new Size(wb, hb);
                        butoaneCalendar[i, j].BackColor = VariabileGlobale.culori[2];
                        butoaneCalendar[i, j].Text = "" + nr;
                        butoaneCalendar[i, j].ForeColor = VariabileGlobale.culori[6];
                        butoaneCalendar[i, j].Font = new Font("Segoe Print", 18);
                        int auxnr = nr;
                        nr++;
                        butoaneCalendar[i, j].Click += delegate (object sender1, EventArgs e1)
                        {
                            ButonCalendar_Click(sender1, e1, auxnr, luna, an);
                        };
                        butoaneCalendar[i, j].Location = new Point(j * wb, 100 + i * hb);
                        this.panelCalendar.Controls.Add(butoaneCalendar[i, j]);
                    }
                }
            }
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            for (int q = 0; q < VariabileGlobale.m; q++)
            {
                SqlCommand selectare = new SqlCommand("SELECT * FROM TabelEvenimente WHERE ((Luna  = '" + luna + "' AND An = '" + an + "') OR SeRepeta = 'True') AND (Categorie = '" + VariabileGlobale.categorii[q] + "' AND NumeCurs = '" + VariabileGlobale.indrumatori[q] + "')", conexiune);
                SqlDataReader dr = selectare.ExecuteReader();
                while (dr.Read())
                {
                    if (Convert.ToInt32(dr["SeRepeta"]) == 0)
                    {
                        DateTime primaDinLuna = new DateTime(an, luna, 1);
                        int prima = Convert.ToInt32(primaDinLuna.DayOfWeek);
                        if (prima == 0)
                            prima = 7;
                        int nrr = Convert.ToInt32(dr["ZiuaLunii"]) + prima - 2;
                        int i = nrr / 7, j = nrr % 7;
                        butoaneCalendar[i, j].BackColor = VariabileGlobale.culori[3];
                    }
                    else
                    {
                        int ziua = Convert.ToInt32(dr["ZiuaSaptamanii"]) - 1;
                        DateTime x = new DateTime(an, luna, 1);
                        int primaZi = Convert.ToInt32(x.DayOfWeek);
                        if (primaZi == 0)
                            primaZi = 7;
                        int ultimaZi = primaZi + Convert.ToInt32(DateTime.DaysInMonth(an, luna)) - 1;
                        for (int i = 0; i < 6; i++)
                        {
                            if (i * 7 + ziua >= primaZi - 1 && i * 7 + ziua < ultimaZi)
                                if (butoaneCalendar[i, ziua].BackColor != VariabileGlobale.culori[3])
                                    butoaneCalendar[i, ziua].BackColor = VariabileGlobale.culori[4];
                        }
                    }
                }
                dr.Close();
            }

        }

        private void panelCulori_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBoxCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxNume.Items.Clear();
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand comanda = new SqlCommand("SELECT DISTINCT NumeCurs FROM TabelEvenimente WHERE Categorie = '" + comboBoxCategoria.SelectedItem.ToString() + "'", conexiune);
            SqlDataReader dr = comanda.ExecuteReader();
            while(dr.Read())
            {
                comboBoxNume.Items.Add("" + dr[0]);
            }
            dr.Close();
            conexiune.Close();
        }

        private void comboBoxNume_SelectedIndexChanged(object sender, EventArgs e)
        {
            ok_combobox = true;
        }

        private void buttonUrmareste_Click(object sender, EventArgs e)
        {
            if(ok_combobox == false)
            {
                MessageBox.Show("Selectati categoria si indrumatorul");
                return;
            }
            if (VariabileGlobale.m < 20)
            {
                SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
                conexiune.Open();
                int ok2 = 1;
                for (int i = 0; i < VariabileGlobale.m; i++)
                    if (VariabileGlobale.indrumatori[i] == comboBoxNume.Text && VariabileGlobale.categorii[i] == comboBoxCategoria.Text)
                        ok2 = 0;
                if (ok2 == 1)
                {
                    SqlCommand insertie = new SqlCommand("INSERT INTO TabelUrmariri VALUES ('" + VariabileGlobale.idCurent + "', '" + comboBoxCategoria.Text + "' , '" + comboBoxNume.Text + "')", conexiune);
                    insertie.ExecuteNonQuery();
                    VariabileGlobale.indrumatori[VariabileGlobale.m] = comboBoxNume.Text;
                    VariabileGlobale.categorii[VariabileGlobale.m] = comboBoxCategoria.Text;
                    VariabileGlobale.m++;
                    MessageBox.Show("Ai inceput sa urmaresti categoria " + comboBoxCategoria.Text + " a indrumatorului " + comboBoxNume.Text);
                }
                else
                    MessageBox.Show("Deja urmaresti categoria " + comboBoxCategoria.Text + " a indrumatorului " + comboBoxNume.Text);
            }
            else
                MessageBox.Show("Urmaresti prea multi indrumatori");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ok_combobox == false)
            {
                MessageBox.Show("Selectati categoria si indrumatorul");
                return;
            }
            SqlConnection conexiune = new SqlConnection(VariabileGlobale.connString);
            conexiune.Open();
            SqlCommand verificare = new SqlCommand("SELECT * FROM TabelUrmariri WHERE Id_Utilizator = '" + VariabileGlobale.idCurent + "' AND NumeProfesor = '" + comboBoxNume.Text + "' AND Categorie = '" + comboBoxCategoria.Text + "'", conexiune);
            SqlDataReader dr = verificare.ExecuteReader();
            int ok = 0;
            if(dr.Read())
            {
                ok = 1;
            }
            dr.Close();
            if (ok == 1)
            {
                SqlCommand stergere = new SqlCommand("DELETE FROM TabelUrmariri WHERE Id_Utilizator = '" + VariabileGlobale.idCurent + "' AND Categorie = '" + comboBoxCategoria.Text + "' AND NumeProfesor = '" + comboBoxNume.Text + "'", conexiune);
                stergere.ExecuteNonQuery();
                int ok_for = 1;
                for (int i = 0; i < VariabileGlobale.m && ok_for == 1; i++)
                {
                    if (VariabileGlobale.indrumatori[i] == comboBoxNume.Text && VariabileGlobale.categorii[i] == comboBoxCategoria.Text)
                    {
                        ok_for = 0;
                        for (int j = i + 1; j < VariabileGlobale.m; j++)
                        {
                            VariabileGlobale.indrumatori[j - 1] = VariabileGlobale.indrumatori[j];
                            VariabileGlobale.categorii[j - 1] = VariabileGlobale.categorii[j];
                        }
                    }
                }
                VariabileGlobale.m--;
                MessageBox.Show("Nu mai urmaresti acest indrumator pentru acesta categorie");
            }
            else
                MessageBox.Show("Nu urmaresti indrumatorul acestei categorii");
        }

        private void panelPaleteCulori_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonMeniu_Click(object sender, EventArgs e)
        {
            FormStart fs = new FormStart();
            this.Hide();
            fs.ShowDialog();
        }
    }
}
